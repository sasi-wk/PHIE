# angular2-fast-start
A repo to get you up and running with Angular 2
